#include <math.h>
#define MAX(x,y) ( x>y ? x : y )

double func (double x) {
  return pow(x,1.5)/3.1 - x/log(3.0);
}
